module.exports = require('../../scripts/webpack.client')(__dirname);
